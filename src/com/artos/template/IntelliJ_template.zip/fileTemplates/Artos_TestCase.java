#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.artos.annotation.TestCase;
import com.artos.annotation.TestPlan;
import com.artos.annotation.Unit;
import com.artos.framework.infra.TestContext;
import com.artos.interfaces.TestExecutable;

@TestPlan(preparedBy = "${USER}", preparationDate = "${DATE}", bdd = "GIVEN..WHEN..AND..THEN..")
@TestCase
public class ${NAME} implements TestExecutable {
    
    @Unit
	public void testUnit_1(TestContext context) {
		// --------------------------------------------------------------------------------------------
		// TODO Write Test Here
		// --------------------------------------------------------------------------------------------
	}
}