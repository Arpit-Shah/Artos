#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import com.artos.annotation.StepDefinition;
import com.artos.framework.infra.TestContext;
import com.artos.interfaces.TestExecutable;

public class ${NAME} implements TestExecutable {
    
    @StepDefinition("User login using username \"username\" password \"password\"")
	public void _user_login_using_username_password(TestContext context) {
		// --------------------------------------------------------------------------------------------
		// TODO Write Test Here
		context.getLogger().info("UserName: " + context.getStepParameter("Param0"));
		context.getLogger().info("Password: " + context.getStepParameter("Param1"));
		// --------------------------------------------------------------------------------------------
	}

	@StepDefinition("User browse to page \"<pagename>\"")
	public void _user_browse_to_page(TestContext context) {
		// --------------------------------------------------------------------------------------------
		context.getLogger().info("Page Name: " + context.getStepParameter("pagename"));
		// --------------------------------------------------------------------------------------------
	}

	@StepDefinition("User click on button \"<buttonname>\"")
	public void _user_click_on_button(TestContext context) {
		// --------------------------------------------------------------------------------------------
		context.getLogger().info("Button Text: " + context.getStepParameter("buttonname"));
		// --------------------------------------------------------------------------------------------
	}
}