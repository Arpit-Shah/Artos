#if (${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
        
import com.artos.framework.infra.Runner;
import com.google.common.collect.Lists;

public class ${NAME} {

	public static void main(String[] args) throws Exception {
		Runner runner = new Runner(${NAME}.class);
		runner.setFeatureFileList(Lists.newArrayList("CreatePostFeature.feature"));
		runner.run(args);
	}

}